import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'epochToDate'
})
export class EpochToDatePipe implements PipeTransform {

  transform(value: number, multiply: string): string { 
    let mul = parseFloat(multiply); 
    let myDate = new Date(value * 1000);
    //let mynewDate=myDate.toUTCString();
    let mynewDate=myDate.toDateString();
    return mynewDate;
 }

}
